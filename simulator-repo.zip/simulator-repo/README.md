# Poker Simulator · 六人桌策略模拟器

本地网页版模拟器：六个座位各加载一份 JavaScript 策略，同场对打；保存脚本自动跑一轮，结果可视化，历史落盘并可 A/B 对比。

## 快速开始

```bash
npm start          # 打开 http://127.0.0.1:8787
```

无需安装依赖、无需构建，Node.js ≥ 20 即可。

## 内置策略

`strategies/official/` 是本人在官方比赛里表现最好的两个版本：

| 文件 | 版本 | 官方成绩 |
| --- | --- | --- |
| `v5-rule-mix-v10.js` | 平台版本 5 | 351 场，平均 +1,472/场，平均名次 2.28，第一名率 23.7% |
| `v6-rule-mix-v11a.js` | 平台版本 6 | 259 场，平均 +461/场，平均名次 2.53，第一名率 14.7% |

`strategies/reference/` 放了 v3 / v8 / v16 / v4 作为对照，六个座位由 `strategies/manifest.json` 决定。

想换成自己的脚本：直接改 UI 里的代码框（保存即生效），或者编辑 `manifest.json` 指向新文件后删除 `simulator-data/` 重置。

## 运行规则

- 六个座位同场，每场 240 手；引擎每 40 手轮换一次座位，240 手正好让每个策略坐遍六个位置。
- 同一场内六家看到完全相同的牌序，牌运被对冲，剩下的差异就是策略差异。
- 每场基准按钮由种子派生；结果里的 `faults` 必须为 0，非 0 说明某个脚本返回了非法动作。

## 界面

- 六个编辑器：座位名 + 代码，**保存并自动跑**；
- 结果区：排名表（平均净额、95% CI、平均名次、第一名率、前二率）、净额条形图、两两差值矩阵；
- 历史区：每次运行一条记录，可查看，也可任选两次做 A/B 对比。

## 策略契约

单文件、自包含，必须定义：

```js
function act(view) {
  // view.legal 里挑一个动作返回
  return { type: 'call' };
}
```

- 只能返回 `fold / check / call / bet / raise / allin`，且必须在 `view.legal` 内；
- 4 MiB 源码上限、控制字符检查、2 秒初始化超时；
- 每个阶段重新实例化，脚本之间不共享状态；
- 脚本运行在 Node `vm` 沙箱里（`lib/local/strategy_runtime.js`）。

## 目录

```text
server.js                 HTTP 服务与 API
public/                   UI（原生 HTML/CSS/JS，无框架）
lib/simulation/           牌堆、下注、边池、240 手比赛引擎
lib/evaluation/           5–7 张牌评估器
lib/statistics/           比赛级 bootstrap 区间与描述统计
lib/local/                策略加载与动作合法性校验
lib/simulator/            六座位调度与历史存储
strategies/official/      v5、v6 正式策略
strategies/reference/     对照版本
```

## 数据

`simulator-data/scripts.json` 保存六个座位当前脚本，`simulator-data/runs/*.json` 保存每次运行的完整结果。该目录不进入版本库，删除即重置。

## 测试

```bash
npm test
```

## 说明

引擎与统计口径和本人的策略研究工作区一致；本仓库只包含模拟器运行所需的代码，不包含官方比赛数据、账号信息或提交工具。

---

English: a dependency-free local web app that pits six JavaScript poker strategies against each other in a six-max, 240-hand match, with a browser UI for editing, running, charting and comparing runs. `npm start`, then open http://127.0.0.1:8787.

## 常见问题

- **端口被占用**：`npm start -- --port=8790`（参数会透传给 `server.js`）。
- **想清空历史/回到内置策略**：删掉 `simulator-data/` 目录，下次启动会按 `strategies/manifest.json` 重新播种。
- **Node 版本**：需要 Node 20 及以上（`package.json` 的 `engines` 有声明），在本机 Node 24 上验证通过。
- **不需要 `npm install`**：没有任何第三方依赖，也没有任何 CDN 或外网请求。
