'use strict';

const state = {
  slots: [],
  history: [],
  currentRun: null,
  compareA: null,
  compareB: null,
  busy: false,
};

const $ = (selector) => document.querySelector(selector);

function fmt(value, digits = 0) {
  if (!Number.isFinite(value)) return '-';
  return value.toLocaleString('en-US', { maximumFractionDigits: digits, minimumFractionDigits: digits });
}

function signed(value, digits = 0) {
  const formatted = fmt(Math.abs(value), digits);
  return value >= 0 ? `+${formatted}` : `-${formatted}`;
}

function setStatus(text, kind = '') {
  const status = $('#status');
  status.textContent = text;
  status.style.color = kind === 'error' ? 'var(--bad)' : kind === 'ok' ? 'var(--good)' : 'var(--muted)';
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error ?? `HTTP ${response.status}`);
  return body;
}

function renderEditors() {
  const container = $('#editors');
  container.textContent = '';
  const template = $('#editorTemplate');
  state.slots.forEach((slot, index) => {
    const node = template.content.firstElementChild.cloneNode(true);
    node.dataset.slot = String(index);
    node.querySelector('.seat').textContent = `S${index + 1}`;
    node.querySelector('.name').value = slot.name;
    node.querySelector('.source').value = slot.source;
    node.querySelector('.stamp').textContent = slot.updatedAt
      ? `更新于 ${new Date(slot.updatedAt).toLocaleString()}`
      : '';
    node.querySelector('.save').addEventListener('click', () => saveSlot(index, node));
    container.appendChild(node);
  });
}

async function saveSlot(index, node) {
  if (state.busy) return;
  const name = node.querySelector('.name').value.trim() || `slot-${index + 1}`;
  const source = node.querySelector('.source').value;
  const status = node.querySelector('.slot-status');
  const matches = Number($('#matches').value);
  state.busy = true;
  status.textContent = '保存并运行中…';
  setStatus(`S${index + 1} 保存并自动跑 ${matches} 场…`);
  try {
    const body = await api(`/api/slots/${index}`, {
      method: 'POST',
      body: JSON.stringify({ name, source, autoRun: true, autoMatches: matches, seed: Number($('#seed').value) }),
    });
    state.slots[index] = { ...state.slots[index], ...body.slot, slot: index };
    status.textContent = '已保存';
    setStatus(body.runError ? `保存成功，但自动跑失败：${body.runError}` : '保存完成', body.runError ? 'error' : 'ok');
    if (body.run) applyRun(body.run, false);
    await refreshHistory();
  } catch (error) {
    status.textContent = '保存失败';
    setStatus(error.message, 'error');
  } finally {
    state.busy = false;
  }
}

function renderSummary(run) {
  const rows = run.slots.map((slot, index) => {
    const rank = index + 1;
    const ci = slot.netCI ? `[${fmt(slot.netCI.lower)}, ${fmt(slot.netCI.upper)}]` : '-';
    return `<tr>
      <td>${rank} · ${escapeHtml(slot.name)}</td>
      <td class="${slot.net.mean >= 0 ? 'pos' : 'neg'}">${signed(slot.net.mean)}</td>
      <td>${ci}</td>
      <td>${fmt(slot.meanRank, 2)}</td>
      <td>${fmt(slot.firstPlaceRate * 100, 1)}%</td>
      <td>${fmt(slot.topTwoRate * 100, 1)}%</td>
    </tr>`;
  }).join('');
  $('#summary').innerHTML = `<table>
    <thead><tr><th>座位 / 策略</th><th>平均净额</th><th>95% CI</th><th>平均名次</th><th>第一名率</th><th>前二率</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

function renderChart(run) {
  const slots = run.slots;
  const values = slots.flatMap((slot) => [slot.netCI?.lower ?? slot.net.mean, slot.netCI?.upper ?? slot.net.mean]);
  const min = Math.min(0, ...values);
  const max = Math.max(0, ...values);
  const span = max - min || 1;
  const width = 720;
  const rowHeight = 34;
  const height = slots.length * rowHeight + 30;
  const padLeft = 150;
  const padRight = 80;
  const scale = (value) => padLeft + ((value - min) / span) * (width - padLeft - padRight);
  const zero = scale(0);
  const bars = slots.map((slot, index) => {
    const y = 20 + index * rowHeight;
    const x = scale(slot.net.mean);
    const left = Math.min(zero, x);
    const barWidth = Math.max(1, Math.abs(x - zero));
    const color = slot.net.mean >= 0 ? '#35c48a' : '#ef5d6b';
    const lower = slot.netCI ? scale(slot.netCI.lower) : x;
    const upper = slot.netCI ? scale(slot.netCI.upper) : x;
    return `<g>
      <text x="8" y="${y + 14}" fill="#98a1b3" font-size="12">${escapeHtml(slot.name)}</text>
      <rect x="${left}" y="${y + 4}" width="${barWidth}" height="18" fill="${color}" opacity="0.85" rx="3"></rect>
      <line x1="${lower}" y1="${y + 13}" x2="${upper}" y2="${y + 13}" stroke="#e6e9ef" stroke-width="1.2" opacity="0.7"></line>
      <line x1="${lower}" y1="${y + 8}" x2="${lower}" y2="${y + 18}" stroke="#e6e9ef" stroke-width="1.2" opacity="0.7"></line>
      <line x1="${upper}" y1="${y + 8}" x2="${upper}" y2="${y + 18}" stroke="#e6e9ef" stroke-width="1.2" opacity="0.7"></line>
      <text x="${width - 6}" y="${y + 16}" fill="#e6e9ef" font-size="12" text-anchor="end">${signed(slot.net.mean)}</text>
    </g>`;
  }).join('');
  $('#chart').innerHTML = `<svg viewBox="0 0 ${width} ${height}" width="100%" role="img" aria-label="平均净额与 95% 区间">
    <line x1="${zero}" y1="10" x2="${zero}" y2="${height - 10}" stroke="#2a2f3a" stroke-width="1"></line>
    ${bars}
  </svg>`;
}

function renderMatrix(run) {
  const names = run.slots.map((slot) => slot.name);
  const bySlot = new Map(run.slots.map((slot) => [slot.slot, slot]));
  const pairs = new Map(run.pairs.map((pair) => [`${pair.left}-${pair.right}`, pair]));
  const header = `<tr><th></th>${names.map((name) => `<th>${escapeHtml(name)}</th>`).join('')}</tr>`;
  const body = names.map((name, rowIndex) => {
    const cells = names.map((other, columnIndex) => {
      if (rowIndex === columnIndex) return '<td class="diag">—</td>';
      const pair = pairs.get(`${rowIndex}-${columnIndex}`) ?? pairs.get(`${columnIndex}-${rowIndex}`);
      if (!pair) return '<td>-</td>';
      const value = pair.left === rowIndex ? pair.meanDifference : -pair.meanDifference;
      const significant = value > 0 ? pair.lower > 0 : pair.upper < 0;
      const color = significant ? (value > 0 ? 'var(--good)' : 'var(--bad)') : 'var(--muted)';
      return `<td style="color:${color}">${signed(value)}</td>`;
    }).join('');
    return `<tr><td>${escapeHtml(name)}</td>${cells}</tr>`;
  }).join('');
  $('#matrix').innerHTML = `<h2 style="margin:14px 0 6px">两两差值（行 − 列，每场净额）</h2>
    <table><thead>${header}</thead><tbody>${body}</tbody></table>
    <p class="hint">高亮表示 95% 区间不包含 0。</p>`;
}

function renderRun(run) {
  state.currentRun = run;
  $('#runMeta').textContent = `${run.totals.matches} 场 × ${run.config.hands} 手 · seed ${run.config.seed} · ${new Date(run.createdAt).toLocaleString()} · faults ${run.totals.faults}`;
  renderSummary(run);
  renderChart(run);
  renderMatrix(run);
}

function applyRun(run, scroll = true) {
  renderRun(run);
  if (scroll) $('#runMeta').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function renderHistory() {
  const list = $('#historyList');
  list.textContent = '';
  for (const item of state.history) {
    const li = document.createElement('li');
    li.className = 'history-item';
    if (state.compareA === item.id) li.classList.add('selected-a');
    if (state.compareB === item.id) li.classList.add('selected-b');
    li.innerHTML = `<div class="row"><strong>${new Date(item.createdAt).toLocaleString()}</strong><span>${item.totals.matches}场</span></div>
      <div class="row"><span class="hint">seed ${item.config.seed} · ${item.config.hands}手</span></div>
      <div class="row"><span class="hint">最佳：${escapeHtml(item.best ?? '-')} ${Number.isFinite(item.bestNet) ? signed(item.bestNet) : ''}</span></div>
      <div class="actions">
        <button data-action="view">查看</button>
        <button data-action="a">设为 A</button>
        <button data-action="b">设为 B</button>
      </div>`;
    li.querySelector('[data-action="view"]').addEventListener('click', () => loadRun(item.id));
    li.querySelector('[data-action="a"]').addEventListener('click', () => { state.compareA = item.id; renderHistory(); renderCompare(); });
    li.querySelector('[data-action="b"]').addEventListener('click', () => { state.compareB = item.id; renderHistory(); renderCompare(); });
    list.appendChild(li);
  }
}

async function loadRun(id) {
  try {
    const { run } = await api(`/api/runs/${encodeURIComponent(id)}`);
    applyRun(run);
    $('#compareInfo').textContent = '';
  } catch (error) {
    setStatus(error.message, 'error');
  }
}

async function renderCompare() {
  const info = $('#compareInfo');
  const table = $('#compareTable');
  if (!state.compareA || !state.compareB) {
    info.textContent = '选择两次运行（A/B）即可对比同名策略的变化。';
    table.innerHTML = '';
    return;
  }
  try {
    const [a, b] = await Promise.all([
      api(`/api/runs/${encodeURIComponent(state.compareA)}`).then((r) => r.run),
      api(`/api/runs/${encodeURIComponent(state.compareB)}`).then((r) => r.run),
    ]);
    const mapA = new Map(a.slots.map((slot) => [slot.name, slot]));
    const rows = b.slots.map((slot) => {
      const previous = mapA.get(slot.name);
      if (!previous) return `<tr><td>${escapeHtml(slot.name)}</td><td>-</td><td>${signed(slot.net.mean)}</td><td class="hint">新增</td></tr>`;
      const diff = slot.net.mean - previous.net.mean;
      return `<tr><td>${escapeHtml(slot.name)}</td><td>${signed(previous.net.mean)}</td><td>${signed(slot.net.mean)}</td>
        <td class="${diff >= 0 ? 'pos' : 'neg'}">${signed(diff)}</td></tr>`;
    }).join('');
    info.textContent = `A：${new Date(a.createdAt).toLocaleString()} → B：${new Date(b.createdAt).toLocaleString()}`;
    table.innerHTML = `<table class="compare-table">
      <thead><tr><th>策略</th><th>A 平均净额</th><th>B 平均净额</th><th>变化</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
  } catch (error) {
    info.textContent = error.message;
  }
}

async function refreshHistory() {
  const data = await api('/api/state');
  state.history = data.history;
  renderHistory();
}

async function runNow() {
  if (state.busy) return;
  state.busy = true;
  const button = $('#run');
  button.disabled = true;
  setStatus('运行中…');
  try {
    const body = await api('/api/run', {
      method: 'POST',
      body: JSON.stringify({
        matches: Number($('#matches').value),
        seed: Number($('#seed').value),
        hands: Number($('#hands').value),
      }),
    });
    applyRun(body.run);
    setStatus(`完成：${body.run.totals.matches} 场，0 到 ${body.run.totals.faults} faults`, 'ok');
    await refreshHistory();
  } catch (error) {
    setStatus(error.message, 'error');
  } finally {
    state.busy = false;
    button.disabled = false;
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

async function init() {
  try {
    const data = await api('/api/state');
    state.slots = data.slots;
    state.history = data.history;
    renderEditors();
    renderHistory();
    if (data.defaults) {
      $('#matches').value = data.defaults.matches;
      $('#seed').value = data.defaults.seed;
      $('#hands').value = data.defaults.hands;
    }
    if (state.history.length > 0) await loadRun(state.history[0].id);
    await renderCompare();
    setStatus('就绪');
  } catch (error) {
    setStatus(`初始化失败：${error.message}`, 'error');
  }
}

$('#run').addEventListener('click', runNow);
$('#clearCompare').addEventListener('click', () => {
  state.compareA = null;
  state.compareB = null;
  renderHistory();
  renderCompare();
});

init();
