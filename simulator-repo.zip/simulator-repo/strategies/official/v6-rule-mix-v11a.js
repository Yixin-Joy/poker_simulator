/* Candidate rules-v11a: v10 with wider preflop flat-call defense.
 * Raise targets are total street commitments. No player-keyed adaptation and
 * no state survives a call to act(view).
 */

const RM_RANKS = '23456789TJQKA';

function rmRank(card) {
  return RM_RANKS.indexOf(card[0]) + 2;
}

function rmPassive(view) {
  if (view.toCall === 0 && view.legal.includes('check')) return { type: 'check' };
  if (view.legal.includes('fold')) return { type: 'fold' };
  if (view.legal.includes('call')) return { type: 'call' };
  if (view.legal.includes('allin')) return { type: 'allin' };
  throw new Error('No legal passive action');
}

function rmCall(view) {
  if (view.toCall > 0 && view.legal.includes('call')) return { type: 'call' };
  return rmPassive(view);
}

function rmRaiseTo(view, desired) {
  const type = view.legal.includes('raise')
    ? 'raise'
    : view.legal.includes('bet')
      ? 'bet'
      : null;
  if (type === null || !view.canRaise) return null;
  const minimum = Math.ceil(view.minRaiseTo);
  const maximum = Math.floor(view.maxRaiseTo);
  if (minimum > maximum) return null;
  const target = Math.max(minimum, Math.min(maximum, Math.floor(desired)));
  return { type: type, to: target };
}

function rmPreflopScore(cards) {
  const first = rmRank(cards[0]);
  const second = rmRank(cards[1]);
  const high = Math.max(first, second);
  const low = Math.min(first, second);
  if (high === low) return 54 + high * 3;

  let score = high * 4 + low * 1.15;
  if (cards[0][1] === cards[1][1]) score += 5;
  const gap = high - low - 1;
  if (gap === 0) score += 2;
  else if (gap === 1) score += 1;
  else if (gap === 2) score -= 1;
  else if (gap === 3) score -= 3;
  else score -= 5;
  if (low >= 10) score += 3;
  if (high === 14 && low >= 10) score += 4;
  return score;
}

function rmPreflopRaises(view) {
  return view.actions.filter(
    (action) => action.street === 'preflop'
      && (
        action.type === 'raise'
        || action.type === 'bet'
        || action.type === 'allin'
        || action.type === 'all_in'
      ),
  ).length;
}

function rmCurrentStreetTotal(view) {
  return view.me.bet + view.toCall;
}

function rmPreflopDecision(view) {
  const score = rmPreflopScore(view.me.cards);
  const position = view.me.position;
  const raises = rmPreflopRaises(view);
  const toCall = view.toCall;
  const potOdds = toCall / Math.max(1, view.pot + toCall);
  const facingAllIn = view.players.some(
    (player) => player.seat !== view.seat && player.state === 'allin',
  );
  const openThreshold = position === 'UTG'
    ? 72
    : position === 'HJ'
      ? 68
      : position === 'CO'
        ? 58
        : position === 'BTN'
          ? 48
          : position === 'SB'
            ? 60
            : 58;

  if (facingAllIn && toCall > 0) {
    const commitment = toCall / Math.max(1, view.me.stack);
    const callThreshold = commitment >= 0.7 ? 84 : 72;
    if (
      score >= callThreshold
      && potOdds <= 0.62
      && view.legal.includes('call')
    ) {
      return { type: 'call' };
    }
    return rmPassive(view);
  }

  if (raises === 0) {
    const limpers = view.actions.filter(
      (action) => action.street === 'preflop' && action.type === 'call',
    ).length;
    const raiseThreshold = Math.max(45, openThreshold - (limpers > 0 ? 2 : 0));
    if (score >= raiseThreshold) {
      const desired = Math.max(
        view.level.bb * (3 + limpers),
        view.minRaiseTo,
      );
      const raise = rmRaiseTo(view, desired);
      if (raise) return raise;
    }
    return rmPassive(view);
  }

  const currentTotal = rmCurrentStreetTotal(view);
  const latePosition = position === 'SB' || position === 'BTN' || position === 'CO';
  const threeBetThreshold = latePosition ? 70 : 74;
  if (raises === 1 && score >= threeBetThreshold && toCall < view.me.stack * 0.35) {
    const raise = rmRaiseTo(
      view,
      Math.max(view.minRaiseTo, currentTotal * 2.8, view.pot + toCall),
    );
    if (raise) return raise;
  }
  if (raises >= 2 && score >= 90 && toCall < view.me.stack * 0.4) {
    const raise = rmRaiseTo(
      view,
      Math.max(view.minRaiseTo, currentTotal * 2.5, view.pot + toCall),
    );
    if (raise) return raise;
  }

  const defenseThreshold = position === 'BB'
    ? 54
    : position === 'SB'
      ? 55
      : position === 'BTN' || position === 'CO'
        ? 54
        : 62;
  const callThreshold = raises === 1 ? defenseThreshold : 80;
  const priceCap = raises === 1 ? 0.40 : 0.42;
  if (
    score >= callThreshold
    && potOdds <= priceCap
    && toCall <= view.me.stack * 0.30
  ) {
    return rmCall(view);
  }
  if (score >= 84 && potOdds <= 0.42 && toCall <= view.me.stack * 0.32) {
    return rmCall(view);
  }
  return rmPassive(view);
}

function rmStraightHigh(ranks) {
  const present = new Set(ranks);
  for (let high = 14; high >= 5; high -= 1) {
    if (
      present.has(high)
      && present.has(high - 1)
      && present.has(high - 2)
      && present.has(high - 3)
      && present.has(high - 4)
    ) {
      return high;
    }
  }
  if (
    present.has(14)
    && present.has(2)
    && present.has(3)
    && present.has(4)
    && present.has(5)
  ) {
    return 5;
  }
  return 0;
}

function rmAssess(view) {
  const holeRanks = view.me.cards.map(rmRank);
  const boardRanks = view.board.map(rmRank);
  const allRanks = holeRanks.concat(boardRanks);
  const counts = {};
  const suits = {};
  for (let index = 0; index < allRanks.length; index += 1) {
    const rank = allRanks[index];
    counts[rank] = (counts[rank] || 0) + 1;
    const card = index < 2 ? view.me.cards[index] : view.board[index - 2];
    suits[card[1]] = (suits[card[1]] || 0) + 1;
  }
  const groups = Object.keys(counts)
    .map(Number)
    .map((rank) => ({ rank: rank, count: counts[rank] }))
    .sort((first, second) => second.count - first.count || second.rank - first.rank);
  const groupCounts = groups.map((group) => group.count);
  const flushSuit = Object.keys(suits).find((suit) => suits[suit] >= 5);
  const allStraight = rmStraightHigh(allRanks);
  const boardStraight = boardRanks.length === 5 ? rmStraightHigh(boardRanks) : 0;
  const boardTop = boardRanks.length ? Math.max(...boardRanks) : 0;
  const pocket = holeRanks[0] === holeRanks[1];
  const matchedBoard = holeRanks.some((rank) => boardRanks.includes(rank));
  const pairUsesHole = pocket || matchedBoard;
  const topPair = pairUsesHole
    && (holeRanks.includes(boardTop) || (pocket && holeRanks[0] > boardTop));

  let category = 0;
  if (flushSuit && rmStraightHigh(allRanks.filter((rank, index) => {
    const card = index < 2 ? view.me.cards[index] : view.board[index - 2];
    return card[1] === flushSuit;
  }))) category = 8;
  else if (groupCounts[0] === 4) category = 7;
  else if (groupCounts[0] === 3 && groupCounts[1] >= 2) category = 6;
  else if (flushSuit) category = 5;
  else if (allStraight) category = 4;
  else if (groupCounts[0] === 3) category = 3;
  else if (groupCounts[0] === 2 && groupCounts[1] === 2) category = 2;
  else if (groupCounts[0] === 2) category = 1;

  let made = [0.12, 0.32, 0.72, 0.84, 0.82, 0.9, 1, 1, 1][category];
  if (category === 1) made = topPair ? 0.58 : pairUsesHole ? 0.43 : 0.26;
  if (category === 4 && boardStraight && holeRanks.every((rank) => !boardRanks.includes(rank))) {
    made = 0.30;
  }
  if (category === 5) {
    const holeFlush = view.me.cards.some((card) => card[1] === flushSuit);
    made = holeFlush ? 0.90 : 0.34;
  }

  const boardCardCounts = {};
  for (const card of view.board) boardCardCounts[card[1]] = (boardCardCounts[card[1]] || 0) + 1;
  const boardRankCounts = {};
  for (const rank of boardRanks) boardRankCounts[rank] = (boardRankCounts[rank] || 0) + 1;
  let flushDraw = false;
  const suitHole = view.me.cards
    .map((card) => card[1])
    .find((suit) => (suits[suit] || 0) === 4);
  if (suitHole) flushDraw = true;

  let straightDraw = false;
  if (!allStraight && view.street !== 'river') {
    const present = new Set(allRanks);
    if (present.has(14)) present.add(1);
    for (let start = 1; start <= 10; start += 1) {
      let hits = 0;
      let holeHits = 0;
      for (let rank = start; rank < start + 5; rank += 1) {
        if (present.has(rank === 1 && start === 1 ? 14 : rank)) hits += 1;
        if (holeRanks.includes(rank === 1 && start === 1 ? 14 : rank)) holeHits += 1;
      }
      if (hits === 4 && holeHits > 0) {
        straightDraw = true;
        break;
      }
    }
  }

  const outs = (view.street === 'river' ? 0 : flushDraw ? 9 : 0)
    + (view.street === 'river' ? 0 : straightDraw ? 7 : 0);
  const drawEquity = view.street === 'flop'
    ? Math.min(0.5, outs * 0.04)
    : view.street === 'turn'
      ? Math.min(0.35, outs * 0.02)
      : 0;
  const boardPaired = Object.values(boardRankCounts).some((count) => count >= 2);
  const boardThreeFlush = Object.keys(boardCardCounts).some((suit) => boardCardCounts[suit] >= 3);
  const boardConnected = boardRanks.length >= 3 && rmStraightHigh(boardRanks) > 0;
  const dryBoard = !boardPaired && !boardThreeFlush && !boardConnected;

  return {
    category: category,
    made: made,
    drawEquity: drawEquity,
    flushDraw: flushDraw,
    straightDraw: straightDraw,
    topPair: topPair,
    dryBoard: dryBoard,
  };
}

function rmMix(view) {
  const text = [
    view.me.cards.join(','),
    view.board.join(','),
    view.me.position,
    view.street,
    view.pot,
    view.toCall,
    view.me.bet,
    view.me.stack,
    view.actions.length,
  ].join('|');
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619) >>> 0;
  }
  return hash / 4294967296;
}

function rmPostflopDecision(view) {
  const assessment = rmAssess(view);
  const active = view.players.filter((player) => player.state !== 'folded').length;
  const late = view.me.position === 'CO' || view.me.position === 'BTN';
  const mix = rmMix(view);
  const potAfterCall = view.pot + view.toCall;

  if (view.toCall === 0) {
    if (assessment.made >= 0.80) {
      const raise = rmRaiseTo(view, view.me.bet + Math.max(
        view.level.bb,
        Math.floor(potAfterCall * 0.82),
      ));
      if (raise) return raise;
    }
    if (assessment.made >= 0.42 && active <= 4) {
      const raise = rmRaiseTo(view, view.me.bet + Math.max(
        view.level.bb,
        Math.floor(potAfterCall * 0.65),
      ));
      if (raise) return raise;
    }
    if (assessment.drawEquity >= 0.18 && active <= 3 && mix < 0.62) {
      const raise = rmRaiseTo(view, view.me.bet + Math.max(
        view.level.bb,
        Math.floor(potAfterCall * 0.5),
      ));
      if (raise) return raise;
    }
    if (assessment.dryBoard && late && active <= 2 && mix < 0.18) {
      const raise = rmRaiseTo(view, view.me.bet + Math.max(
        view.level.bb,
        Math.floor(potAfterCall * 0.38),
      ));
      if (raise) return raise;
    }
    return rmPassive(view);
  }

  const potOdds = view.toCall / Math.max(1, potAfterCall);
  if (assessment.made >= 0.82) {
    if (view.canRaise && mix < 0.82) {
      const raise = rmRaiseTo(view, rmCurrentStreetTotal(view) + Math.max(
        view.level.bb,
        Math.floor(potAfterCall * 0.8),
      ));
      if (raise) return raise;
    }
    return rmCall(view);
  }
  if (assessment.made >= 0.55) {
    if (active <= 3 && potOdds <= 0.48) {
      if (late && view.canRaise && mix < 0.35) {
        const raise = rmRaiseTo(view, rmCurrentStreetTotal(view) + Math.max(
          view.level.bb,
          Math.floor(potAfterCall * 0.45),
        ));
        if (raise) return raise;
      }
      return rmCall(view);
    }
    return rmPassive(view);
  }
  if (assessment.drawEquity > 0) {
    const multiwayDiscount = active <= 2 ? 1 : 0.85;
    if (
      potOdds <= assessment.drawEquity * multiwayDiscount
      && view.toCall <= view.me.stack * 0.35
    ) {
      if (late && active <= 2 && mix < 0.24 && view.canRaise) {
        const raise = rmRaiseTo(view, rmCurrentStreetTotal(view) + Math.max(
          view.level.bb,
          Math.floor(potAfterCall * 0.48),
        ));
        if (raise) return raise;
      }
      return rmCall(view);
    }
    return rmPassive(view);
  }
  if (assessment.made >= 0.30 && potOdds <= 0.28) return rmCall(view);
  if (view.toCall <= view.level.bb * 0.5 && potOdds <= 0.14) return rmCall(view);
  return rmPassive(view);
}

function act(view) {
  if (view.street === 'preflop') return rmPreflopDecision(view);
  return rmPostflopDecision(view);
}

