'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { runTournament } = require('../lib/simulator/runner');

const CHECK_CALL = `function act(view) {
  if (view.legal.indexOf('check') >= 0) return { type: 'check' };
  if (view.legal.indexOf('call') >= 0) return { type: 'call' };
  return { type: 'fold' };
}`;

const FOLD_FIRST = `function act(view) {
  if (view.toCall === 0 && view.legal.indexOf('check') >= 0) return { type: 'check' };
  if (view.legal.indexOf('fold') >= 0) return { type: 'fold' };
  if (view.legal.indexOf('call') >= 0) return { type: 'call' };
  return { type: 'check' };
}`;

function scripts() {
  return Array.from({ length: 6 }, (_, index) => ({
    name: `slot-${index + 1}`,
    source: index % 2 === 0 ? CHECK_CALL : FOLD_FIRST,
  }));
}

test('six-seat run is deterministic and zero-sum', () => {
  const first = runTournament({ scripts: scripts(), matches: 2, seed: 42, hands: 20 });
  const second = runTournament({ scripts: scripts(), matches: 2, seed: 42, hands: 20 });
  assert.equal(first.totals.faults, 0);
  assert.equal(first.slots.length, 6);
  assert.equal(first.pairs.length, 15);
  const total = first.slots.reduce((sum, slot) => sum + slot.net.mean, 0);
  assert.ok(Math.abs(total) < 1e-6);
  assert.deepEqual(
    first.slots.map((slot) => Math.round(slot.net.mean * 1000)),
    second.slots.map((slot) => Math.round(slot.net.mean * 1000)),
  );
});

test('bundled official strategies load and play without faults', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const sources = ['official/v5-rule-mix-v10.js', 'official/v6-rule-mix-v11a.js'].map((file) => ({
    name: file,
    source: fs.readFileSync(path.join(__dirname, '..', 'strategies', file), 'utf8'),
  }));
  const filler = scripts().slice(0, 4).map((script) => ({ ...script, source: CHECK_CALL }));
  const result = runTournament({ scripts: [...sources, ...filler], matches: 1, seed: 7, hands: 20 });
  assert.equal(result.totals.faults, 0);
});
