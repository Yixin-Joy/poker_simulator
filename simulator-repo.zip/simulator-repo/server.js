'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { URL } = require('node:url');

const { runTournament } = require('./lib/simulator/runner');
const { SimulatorStore } = require('./lib/simulator/store');
const { assertSourceContract } = require('./lib/local/strategy_runtime');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const STRATEGY_DIR = path.join(ROOT, 'strategies');
const MANIFEST_PATH = path.join(STRATEGY_DIR, 'manifest.json');
const DATA_DIR = path.join(ROOT, 'simulator-data');
const DEFAULT_PORT = 8787;
const DEFAULT_AUTO_MATCHES = 12;
const MAX_BODY_BYTES = 4 * 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
};

function readBody(request) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    request.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error('Request body is too large'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      const text = Buffer.concat(chunks).toString('utf8');
      if (!text) return resolve({});
      try {
        resolve(JSON.parse(text));
      } catch {
        reject(new Error('Request body is not valid JSON'));
      }
    });
    request.on('error', reject);
  });
}

function sendJson(response, status, value) {
  const body = `${JSON.stringify(value)}\n`;
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  response.end(body);
}

function sendFile(response, filePath) {
  const extension = path.extname(filePath);
  const content = fs.readFileSync(filePath);
  response.writeHead(200, {
    'Content-Type': MIME[extension] ?? 'application/octet-stream',
    'Content-Length': content.length,
    'Cache-Control': 'no-store',
  });
  response.end(content);
}

function defaultSlots() {
  const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
  return manifest.slots.map((entry) => ({
    name: entry.name,
    source: fs.readFileSync(path.join(STRATEGY_DIR, entry.file), 'utf8'),
  }));
}

function createServer({ dataDir } = {}) {
  const store = new SimulatorStore({ dataDir: dataDir ?? DATA_DIR });
  store.seedIfEmpty(defaultSlots());
  let running = false;

  const runOnce = ({ matches, seed, hands, trigger }) => {
    if (running) throw new Error('A simulation is already running');
    running = true;
    try {
      const state = store.getState();
      const scripts = state.slots.map((slot, index) => ({
        name: slot.name,
        source: slot.source,
        slot: index,
      }));
      const result = runTournament({ scripts, matches, seed, hands });
      result.trigger = trigger;
      return store.saveRun(result);
    } finally {
      running = false;
    }
  };

  return http.createServer(async (request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');
    try {
      if (request.method === 'GET' && url.pathname === '/api/state') {
        return sendJson(response, 200, {
          slots: store.getState().slots.map((slot, index) => ({
            slot: index,
            name: slot.name,
            source: slot.source,
            updatedAt: slot.updatedAt,
          })),
          history: store.listRuns(),
          defaults: {
            autoMatches: Number(process.env.SIMULATOR_AUTO_MATCHES ?? DEFAULT_AUTO_MATCHES),
            matches: 24,
            hands: 240,
            seed: 20261109,
          },
        });
      }

      if (request.method === 'POST' && /^\/api\/slots\/\d+$/.test(url.pathname)) {
        const index = Number.parseInt(url.pathname.split('/').at(-1), 10);
        const body = await readBody(request);
        if (index < 0 || index > 5) throw new RangeError('slot must be 0..5');
        assertSourceContract(body.source ?? '', `slot-${index + 1}`);
        const saved = store.saveSlot(index, {
          name: body.name ?? `slot-${index + 1}`,
          source: body.source,
        });
        let run = null;
        let runError = null;
        if (body.autoRun !== false) {
          try {
            run = runOnce({
              matches: Number(body.autoMatches ?? DEFAULT_AUTO_MATCHES),
              seed: Number(body.seed ?? 20261109),
              hands: 240,
              trigger: `slot-${index + 1}`,
            });
          } catch (error) {
            runError = error instanceof Error ? error.message : String(error);
          }
        }
        return sendJson(response, 200, { slot: { slot: index, ...saved }, run, runError });
      }

      if (request.method === 'POST' && url.pathname === '/api/run') {
        const body = await readBody(request);
        const run = runOnce({
          matches: Number(body.matches ?? 24),
          seed: Number(body.seed ?? 20261109),
          hands: Number(body.hands ?? 240),
          trigger: body.trigger ?? 'manual',
        });
        return sendJson(response, 200, { run });
      }

      if (request.method === 'GET' && /^\/api\/runs\/[^/]+$/.test(url.pathname)) {
        const id = decodeURIComponent(url.pathname.split('/').at(-1));
        const run = store.getRun(id);
        if (!run) return sendJson(response, 404, { error: 'run not found' });
        return sendJson(response, 200, { run });
      }

      if (request.method === 'DELETE' && /^\/api\/runs\/[^/]+$/.test(url.pathname)) {
        const id = decodeURIComponent(url.pathname.split('/').at(-1));
        return sendJson(response, 200, { deleted: store.deleteRun(id) });
      }

      if (request.method === 'GET') {
        const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        const resolved = path.resolve(PUBLIC_DIR, relative);
        if (!resolved.startsWith(PUBLIC_DIR) || !fs.existsSync(resolved)) {
          response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
          return response.end('Not found');
        }
        return sendFile(response, resolved);
      }

      return sendJson(response, 405, { error: 'method not allowed' });
    } catch (error) {
      return sendJson(response, 400, { error: error instanceof Error ? error.message : String(error) });
    }
  });
}

function main() {
  const portArgument = process.argv.find((value) => value.startsWith('--port='));
  const port = Number(process.env.SIMULATOR_PORT ?? (portArgument ? portArgument.slice(7) : DEFAULT_PORT));
  const server = createServer();
  server.listen(port, '127.0.0.1', () => {
    console.log(`Poker simulator: http://127.0.0.1:${port}`);
  });
}

if (require.main === module) main();

module.exports = { createServer };
